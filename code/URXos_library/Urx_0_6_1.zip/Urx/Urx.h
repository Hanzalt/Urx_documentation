/*
 *    LedControl.h - A library for controling Leds with a MAX7219/MAX7221
 *    Copyright (c) 2007 Eberhard Fahle
*/
#ifndef Urx_h
#define Urx_h

#include <avr/pgmspace.h>
#include <Arduino.h>
#include <inttypes.h>
#include <avr/interrupt.h>
#include <pins_arduino.h>
#include "Print.h" 
#include <Wire.h>

const PROGMEM static word Onex4[] = {
0B0000000, 
0B0100000, 
0B1111111, 
0B0000000, 
};
const PROGMEM static word Twox4[] = {
0B0100111, 
0B1001001, 
0B1001001, 
0B0110001, 
};
const PROGMEM static word Threex4[] = {
0B0100010, 
0B1001001, 
0B1001001, 
0B0110110, 
};
const PROGMEM static word Fourx4[] = {
0B1110000, 
0B0001000, 
0B0001000, 
0B1111111, 
};
const PROGMEM static word Fivex4[]= {
0B1110001, 
0B1001001, 
0B1001001, 
0B1000110, 
};
const PROGMEM static word Sixx4[] = {
0B0111110, 
0B1001001, 
0B1001001, 
0B1000110, 
};
const PROGMEM static word Sevenx4[] = {
0B1000000, 
0B1000000, 
0B1001111, 
0B1110000, 
};
const PROGMEM static word Eightx4[] = {
0B0110110, 
0B1001001, 
0B1001001, 
0B0110110, 
};
const PROGMEM static word Ninex4[] = {
0B0110001, 
0B1001001, 
0B1001001, 
0B0111110, 
};
const PROGMEM static word Zerox4[] = {
0B0111110, 
0B1000001, 
0B1000001, 
0B0111110, 
};
const PROGMEM static word GameOverMessage[]  = {
0B1111111111111111, 
0B1111110000111111, 
0B1111000111011111, 
0B1100001111101111, 
0B1100001111100001, 
0B1000001111100001, 
0B1000001111000011, 
0B1000000000011001, 
0B1000000000011001, 
0B1000001111000011, 
0B1000001111100001, 
0B1100001111100001, 
0B1100001111101111, 
0B1111000111011111, 
0B1111110000111111, 
0B1111111111111111, 
};
const PROGMEM static word Win[] = {
0B0000000000000000, 
0B0100011100000000, 
0B0011001100000000, 
0B0100011100000000, 
0B0000000000000000, 
0B0111011100000000, 
0B0101000000000000, 
0B0111011100000000, 
0B0000001000000000, 
0B0111011100000000, 
0B0001000000000000, 
0B0111000000000000, 
0B0000000000000000, 
0B0111110100000000, 
0B0111110100000000, 
0B0000000000000000, 
};
const PROGMEM static word Score[] = {
0B0111010000000000, 
0B0101110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0100010000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0100010000000000, 
0B0111110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0101000000000000, 
0B0010110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0101010000000000, 
};
const PROGMEM static word SnakeMenu[]= {
0B1101, 
0B1101, 
0B1011, 
0B1011, 
};
const PROGMEM static word Nastaveni1[] = {
0B0010, 
0B1110, 
0B0111, 
0B0100, 
};

const PROGMEM static word Nastaveni2[] = {
0B0100, 
0B0111, 
0B1110, 
0B0010, 
};
const PROGMEM static word Intensity[] = {
0B1001, 
0B1111, 
0B1111, 
0B1001, 
};
const PROGMEM static word DancemanMenu[] = {
0B1111, 
0B1001, 
0B1001, 
0B0110, 
};
const PROGMEM static word HighScore[] = {
0B1111, 
0B0100, 
0B0100, 
0B1111, 
};
const PROGMEM static word Galaxian[] = {
0B0110, 
0B1011, 
0B1011, 
0B1010, 
};
const PROGMEM static word HolTyc1[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000000010, 
0B0100000000000010, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000000010, 
0B0100000000000010, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc2[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000001110, 
0B0100000000001110, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000001110, 
0B0100000000001110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc3[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000111110, 
0B0100000000111110, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000111110, 
0B0100000000111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc4[] = {
0B0000000110000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0011111011111100, 
0B0100000011111110, 
0B0100000011111110, 
0B0011111011111100, 
0B0000001011000000, 
0B0000001011000000, 
0B0011111011111100, 
0B0100000011111110, 
0B0100000011111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc5[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100001111111110, 
0B0100001111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100001111111110, 
0B0100001111111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc6[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100111111111110, 
0B0100111111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100111111111110, 
0B0100111111111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc7[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0111111111111110, 
0B0111111111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0111111111111110, 
0B0111111111111110, 
0B0011111111111100, 
0B0000000000000000, 
};

const PROGMEM static word Gold_medal[] = { 
0B0101, 
0B1001, 
0B1111, 
0B0001, 
};
const PROGMEM static word Silver_medal[] = { 
0B0101, 
0B1001, 
0B1011, 
0B0101,
};
const PROGMEM static word Sound_on[] = {
0B001100, 
0B011110, 
0B011110, 
0B111111, 
0B000000, 
0B011110, 
};
const PROGMEM static word Sound_off[] = {
0B001100, 
0B011110, 
0B011110, 
0B111111, 
0B000000, 
0B000000, 
};
const PROGMEM static byte ship[3][2] = {
	{1,0},
	{1,1},
	{1,0}};
extern int Array[16][16];
extern int EnemysG[101];
extern int EnemyDouble[51];
extern int bulletPosition[2];
extern int enBulletPosition1[4];
extern int enBulletPosition2[4];
extern int Enemys[6];
class Images {
	public:
		
		/*
		* Create a new class with Images img = ImagesAll();
		*/
		Images();
		/*
		* Create a new class with Images img = ImagesMin();
		*/
		/*
		*
		*/
		void showNumber(int num, int disp);
		/*
		*
		*/
		void showNumberOled(int num, int disp);
};

class Operator {
	private:
		int SOUND_PIN;
		bool soundState = true;
		bool congratsState = false;
	public:
		/*
		*/
		Operator(int piezo);
		/*
		*
		*/
		void showNumber(int num, int disp);
		/*
		*
		*/
		void showNumberOled(int num, int disp);
		int playSound(int sound, int i);
};

class LedControl {
	private:
        /* The array for shifting the data to the devices */
        byte spidata[16];
        /* Send out a single command to the device */
        void spiTransfer(int addr, byte opcode, byte data);

        /* We keep track of the led-status for all 8 devices in this array */
        byte status[64];
        /* Data is shifted out of this pin*/
        int SPI_MOSI;
        /* The clock is signaled on this pin */
        int SPI_CLK;
        /* This one is driven LOW for chip selectzion */
        int SPI_CS;
        /* The maximum number of devices we use */
        int maxDevices;

    public:
        /* 
         * Create a new controler 
         * Params :
         * dataPin		pin on the Arduino where data gets shifted out
         * clockPin		pin for the clock
         * csPin		pin for selecting the device 
         * numDevices	maximum number of devices that can be controled
         */
        LedControl(int dataPin, int clkPin, int csPin, int numDevices=1);

        /* 
         * Set the shutdown (power saving) mode for the device
         * Params :
         * addr	The address of the display to control
         * status	If true the device goes into power-down mode. Set to false
         *		for normal operation.
         */
        void shutdown(int addr, bool status);

        /* 
         * Set the number of digits (or rows) to be displayed.
         * See datasheet for sideeffects of the scanlimit on the brightness
         * of the display.
         * Params :
         * addr	address of the display to control
         * limit	number of digits to be displayed (1..8)
         */
        void setScanLimit(int addr, int limit);

        /* 
         * Set the brightness of the display.
         * Params:
         * addr		the address of the display to control
         * intensity	the brightness of the display. (0..15)
         */
        void setIntensity(int addr, int intensity);

        /* 
         * Switch all Leds on the display off. 
         * Params:
         * addr	address of the display to control
         */
        void clearDisplay(int addr);

        /* 
         * Set the status of a single Led.
         * Params :
         * addr	address of the display 
         * row	the row of the Led (0..7)
         * col	the column of the Led (0..7)
         * state	If true the led is switched on, 
         *		if false it is switched off
         */
        void setLed(int addr, int row, int col, boolean state);

        /* 
         * Set all 8 Led's in a row to a new state
         * Params:
         * addr	address of the display
         * row	row which is to be set (0..7)
         * value	each bit set to 1 will light up the
         *		corresponding Led.
         */
        void setRow(int addr, int row, byte value);

        /* 
         * Set all 8 Led's in a column to a new state
         * Params:
         * addr	address of the display
         * col	column which is to be set (0..7)
         * value	each bit set to 1 will light up the
         *		corresponding Led.
         */
        void setColumn(int addr, int col, byte value);

};
#endif
