#include "Urx.h"
extern int Array[16][16] {{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }};
extern int EnemysG[101] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
extern int EnemyDouble[51] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
extern int bulletPosition[2] = {0,0};
extern int enBulletPosition1[4] = {0,0,0,0};
extern int enBulletPosition2[4] = {0,0,0,0};
extern int Enemys[6] = {random(0,3),random(0,3),random(0,3),random(0,3),random(0,3),random(0,3)};

extern int foodX = 0;
extern int foodY = 0;
extern unsigned long allTime = 0;
extern unsigned long lastTime = 0;
extern float delayTime = 300;
extern const int delayTimeConst = 230;
extern const int bodyLengthConst = 3;
extern int bodyLength = 3;
extern int gameState = 0;
extern bool startingLedOn = true;
extern byte congrats = 0;
extern int activatorV = 0;
extern int soundDelay = 0;
extern bool soundState = true;
extern bool congratsState = true;
extern bool menuFirstWalkThrough = true;
extern bool goThrough = true;
extern bool load = true;
extern bool lastState = true;
//Movement variables
extern volatile int x = 0;
extern volatile int y = 0;
extern volatile int active = 0;
//volatile bool change = false;
extern int shiftedX = 7;
extern int shiftedY = 7;
extern volatile int allwaysX = 0;
extern volatile int allwaysY = 0;

extern const int addressSound = 1;
extern const int addressSnake1 = 2;
extern const int addressSnake2 = 3;
extern const int addressIntensity = 4;
extern const int addressGalaxian1 = 5;
extern const int addressGalaxian2 = 6;
extern const int addressDanceMan1 = 7;
extern const int addressDanceMan2 = 9;
extern const int forward = 7;
extern const int right = 8;
extern const int left = 6;
extern const int down = 5;
extern const int a = 9;
extern const int soundPin = 4;
extern const int b = 3;
void URX::Games::Snake::generateFood() {
    while (true) {
        for (int i = 0; i < 5; i++) {
            foodX = random(0, 16);
            foodY = random(0, 16);
        }
        if (Array[foodY][foodX] == 0) {
            break;
        }
    }
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 16; col++) {
            //Making Snake timer longer
            if (Array[row][col] > 0) {
                Array[row][col]++;
            }
        }
    }
}
void URX::Games::Snake::begin() {
    Serial.println("begin");
    allTime = millis();
    lastTime = allTime;
    delayTime = delayTimeConst;
    bodyLength = bodyLengthConst;
    activatorV = 0;
    startingLedOn = true;
    congrats = 0;
    shiftedX = 0;
    shiftedY = 15;
    allwaysX = 0;
    allwaysY = 0;
    active = 0;
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 16; col++) {
            Array[row][col] = 0;
        }
    }
    
    LedControl lc;
    lc.clearDisplay();
    Serial.println("b2");
    //U8G2 u8g2;
    //u8g2.displayOled("Your Score: " + String(bodyLength - 3) + "\nHigh Score: " + String(EEPROM.read(addressSnake1)));
    Serial.println("b");
}
void URX::Games::Snake::snakeStart() {
    Serial.println("fine");
    LedControl lc;
    OtherFunctions ot;
    U8G2 u8g2;
    //Local variables Snake
    allTime = millis();
    Serial.println("fine2");
    //Games::Snake snake;
    //Movement: left....x = 1, right....x = -1, forward....y = 1, down....y = -1. 
    if ((x == 0 and y == 0) and startingLedOn == true) {
        lc.displayLed(shiftedY, shiftedX, 1);
        //Serial.print()
    }
    else if (startingLedOn == true) {
        lc.displayLed(shiftedY, shiftedX, 0);
        startingLedOn = false;
    }
    if (activatorV == 1 and (x != 0 or y != 0)) {
        activatorV = 0;
        lastTime = allTime;
    }
    if (active == -1) {
        goThrough = true;
        activatorV = 1;
        active = 0;
        allwaysX = 0;
        allwaysY = 0;
        x = 0;
        y = 0;
        ot.gameOver(bodyLength - 3, 1);
        ot.gameOver(bodyLength - 3, 1);
    }
    if (activatorV == 0 and active == 1 and startingLedOn == false) {
        activatorV = 1;
        y = 0;
        x = 0;
        noTone(soundPin);
    }
    if (((bodyLength - 4) >= EEPROM.read(addressSnake1) and congratsState == true) and congrats <= 3) {
        ot.playSound(9, congrats);
        congratsState = false;
    }
    if (activatorV == 0) {
        // Smart blinking food led 
        lc.displayLed(foodY, foodX, millis() % 1000 < 500 ? 1 : 0);
        // This will run every delayTime
        if (allTime - lastTime >= delayTime) {
            //allwaysY=y;
            //sX=x;
            if (allwaysY != -y and y != 0) {
                allwaysY = y;
                allwaysX = 0;
            }
            else if (allwaysX != -x and x != 0) {
                allwaysX = x;
                allwaysY = 0;
            }
            // Making head bigger
            shiftedY -= allwaysY;
            shiftedX -= allwaysX;
            ot.warp();
            if (Array[shiftedY][shiftedX] > 0) {
                ot.gameOver((bodyLength - 3), 1);
            }
            if (allwaysX != 0 or allwaysY != 0) {
                Array[shiftedY][shiftedX] = bodyLength + 1;
            }
            //This will run only if game snake is on - if you are not dead
            if (gameState == 2) {
                //Big for loop that run for all pixel in array
                for (int row = 0; row < 16; row++) {
                    for (int col = 0; col < 16; col++) {
                        // if there is a body segment, decrement it's value
                        if (Array[row][col] > 0) {
                            Array[row][col]--;
                            //If This pixel is zero (I know that zero means that it is snake ending) turn pixel off
                            if (Array[row][col] == 0) {
                                lc.displayLed(row, col, 0);
                                //If pixel is the biggest turn pixel on
                            }
                            else if (Array[row][col] == bodyLength) {
                                lc.displayLed(row, col, 1);
                            }
                        }
                    }
                }
                if (soundDelay == 0 and (allwaysX != 0 or allwaysY != 0)) {
                    ot.playSound(1, 0);
                }
                //If snake eated the food
                if (Array[shiftedY][shiftedX] == Array[foodY][foodX] && Array[shiftedY][shiftedX] != 0) {
                    //        Serial.println("snez");
                    noTone(soundPin);
                    ot.playSound(2, 0);
                    bodyLength += 1;
                    delayTime -= 0.5;
                    foodX = -1;
                    foodY = -1;
                    generateFood();
                    //u8g2.displayOled("Your Score: " + String(bodyLength - 3) + "\nHigh Score: " + String(EEPROM.read(addressSnake1)));
                }
                //Resetting timer
                lastTime = allTime;
            }
        }
    }
}
void URX::Games::OtherFunctions::gameOver(int score, int game) {
    URX::LedControl lc;
    Serial.println("game over");
    //Changing gameState for gameOver state
    noTone(soundPin);
    soundDelay = 0;
    gameState = 1;
    menuFirstWalkThrough = false;
    //Clearing all displays
    lc.clearDisplay();
    if (game == 1 or game == 2 or game == 4 or game == -1) {
        //Showing text Game over
        lc.displayImage(GameOverMessage);
    }
    else if (game == 3) {
        lc.displayImage(Win);
    }
    //Snake
    if (game == 1) {
        if (EEPROM.read(addressSnake1) <= score) {
            EEPROM.write(addressSnake2, EEPROM.read(addressSnake1));
            EEPROM.write(addressSnake1, score);
        }
        else if (EEPROM.read(addressSnake2) < score) {
            EEPROM.write(addressSnake2, score);
        }
    }
    else if (game == 3) {
        if (read2EEPROM(addressDanceMan1) <= score) {
            write2EEPROM(addressDanceMan2, read2EEPROM(addressDanceMan2));
            write2EEPROM(addressDanceMan1, score);
        }
        else if (read2EEPROM(addressDanceMan2) < score) {
            write2EEPROM(addressDanceMan2, score);
        }
    }
    else if (game == 4) {
        if (EEPROM.read(addressGalaxian1) <= score) {
            EEPROM.write(addressGalaxian2, EEPROM.read(addressGalaxian2));
            EEPROM.write(addressGalaxian1, score);
        }
        else if (EEPROM.read(addressGalaxian2) < score) {
            EEPROM.write(addressGalaxian2, score);
        }
    }
    activeButton();
    //Clearing all displays
    lc.clearDisplay();
    //Showing text score
    if (game != -1) {
        lc.displayImage(Score);
        lc.displayNumbers(score);
        activeButton();
    }
    goThrough = true;
    gameState = 0;
}
void URX::Games::OtherFunctions::write2EEPROM(int address, int number) {
    byte byte1 = (number >> 8) & 0xFF;
    byte byte2 = number & 0xFF;

    EEPROM.write(address, byte1);
    EEPROM.write(address + 1, byte2);
}
int URX::Games::OtherFunctions::read2EEPROM(int address) {
    byte byte1 = EEPROM.read(address);
    byte byte2 = EEPROM.read(address + 1);

    int result = (byte1 << 8) + byte2;
    return result;
}
void URX::Games::OtherFunctions::playSound(int sound, int i) {
    if (soundState == true) {
        if (sound == 1 and congratsState == true) {
            tone(soundPin, 70);
            soundDelay = 100;
        }
        else if (sound == 2) {
            tone(soundPin, 260);
            soundDelay = 250;
        }
        else if (sound == 4) {
            noTone(soundPin);
            tone(soundPin, 147);
            soundDelay = 100;
        }
        else if (sound == 5) {
            noTone(soundPin);
            tone(soundPin, 87);
            soundDelay = 9;
        }
        else if (sound == 9) {
            const float noty[5] = { 130.813,164.814,195,998,329.621 };
            tone(soundPin, noty[i]);
            soundDelay = 200;
        }
    }
}
void URX::Games::OtherFunctions::warp() {
    shiftedX < 0 ? shiftedX += 16 : 0;
    shiftedX > 15 ? shiftedX -= 16 : 0;
    shiftedY < 0 ? shiftedY += 16 : 0;
    shiftedY > 15 ? shiftedY -= 16 : 0;
}
void URX::Games::OtherFunctions::activeButton() {
    active = 0;
    while (true) {
        if (active == 1) {
            break;
        }
    }
}
//the opcodes for the MAX7221 and MAX7219
#define OP_NOOP   0
#define OP_DIGIT0 1
#define OP_DIGIT1 2
#define OP_DIGIT2 3
#define OP_DIGIT3 4
#define OP_DIGIT4 5
#define OP_DIGIT5 6
#define OP_DIGIT6 7
#define OP_DIGIT7 8
#define OP_DECODEMODE  9
#define OP_INTENSITY   10
#define OP_SCANLIMIT   11
#define OP_SHUTDOWN    12
#define OP_DISPLAYTEST 15

URX::LedControl::LedControl(int dataPin, int clkPin, int csPin, int numDevices) {
    SPI_MOSI=dataPin;
    SPI_CLK=clkPin;
    SPI_CS=csPin;
    intensity = EEPROM.read(addressIntensity);
    if(numDevices<=0 || numDevices>8 )
        numDevices=8;
    maxDevices=numDevices;
    pinMode(SPI_MOSI,OUTPUT);
    pinMode(SPI_CLK,OUTPUT);
    pinMode(SPI_CS,OUTPUT);
    digitalWrite(SPI_CS,HIGH);
    SPI_MOSI=dataPin;
    for(int i=0;i<64;i++) 
        status[i]=0x00;
    for(int i=0;i<maxDevices;i++) {
        spiTransfer(i,OP_DISPLAYTEST,0);
        //scanlimit is set to max on startup
        setScanLimit(i,7);
        //decode is done in source
        spiTransfer(i,OP_DECODEMODE,0);
        shutdown(i, false);
        setIntensity(i, intensity);
        clearDisplay();
    }
    
}

void URX::LedControl::shutdown(int addr, bool b) {
    if(addr<0 || addr>=maxDevices)
        return;
    if(b)
        spiTransfer(addr, OP_SHUTDOWN,0);
    else
        spiTransfer(addr, OP_SHUTDOWN,1);
}

void URX::LedControl::setScanLimit(int addr, int limit) {
    if(addr<0 || addr>=maxDevices)
        return;
    if(limit>=0 && limit<8)
        spiTransfer(addr, OP_SCANLIMIT,limit);
}

void URX::LedControl::setIntensity(int addr, int intensity) {
    if(addr<0 || addr>=maxDevices)
        return;
    if(intensity>=0 && intensity<16)	
        spiTransfer(addr, OP_INTENSITY,intensity);
}

void URX::LedControl::clearDisplay() {
    int offset;
    for (int index = 0; index < 4; index++) {
        offset = index * 8;
        for (int i = 0; i < 8; i++) {
            status[offset + i] = 0;
            spiTransfer(index, i + 1, status[offset + i]);
        }
    }
}

void URX::LedControl::setLed(int addr, int row, int column, boolean state) {
    int offset;
    byte val=0x00;

    if(addr<0 || addr>=maxDevices)
        return;
    if(row<0 || row>7 || column<0 || column>7)
        return;
    offset=addr*8;
    val=B10000000 >> column;
    if(state)
        status[offset+row]=status[offset+row]|val;
    else {
        val=~val;
        status[offset+row]=status[offset+row]&val;
    }
    spiTransfer(addr, row+1,status[offset+row]);
}

void URX::LedControl::setRow(int addr, int row, byte value) {
    int offset;
    if(addr<0 || addr>=maxDevices)
        return;
    if(row<0 || row>7)
        return;
    offset=addr*8;
    status[offset+row]=value;
    spiTransfer(addr, row+1,status[offset+row]);
}

void URX::LedControl::setColumn(int addr, int col, byte value) {
    byte val;

    if(addr<0 || addr>=maxDevices)
        return;
    if(col<0 || col>7) 
        return;
    for(int row=0;row<8;row++) {
        val=value >> (7-row);
        val=val & 0x01;
        setLed(addr,row,col,val);
    }
}

void URX::LedControl::spiTransfer(int addr, volatile byte opcode, volatile byte data) {
    //Create an array with the data to shift out
    int offset=addr*2;
    int maxbytes=maxDevices*2;

    for(int i=0;i<maxbytes;i++)
        spidata[i]=(byte)0;
    //put our device data into the array
    spidata[offset+1]=opcode;
    spidata[offset]=data;
    //enable the line 
    digitalWrite(SPI_CS,LOW);
    //Now shift out the data 
    for(int i=maxbytes;i>0;i--)
        shiftOut(SPI_MOSI,SPI_CLK,MSBFIRST,spidata[i-1]);
    //latch the data onto the display
    digitalWrite(SPI_CS,HIGH);
}  

void URX::LedControl::displayBorders(int addr) {
    int allLedTurnOn = 0b11111111;
    int allLedTurnOff = 0b00000000;
    for (int i = 0; i < 4; i++) {
        setRow(i, 0, allLedTurnOff);
        setRow(i, 7, allLedTurnOff);
        setColumn(i, 7, allLedTurnOff);
        setColumn(i, 0, allLedTurnOff);
    }
    setRow(addr, 0, allLedTurnOn);
    setRow(addr, 7, allLedTurnOn);
    setColumn(addr, 7, allLedTurnOn);
    setColumn(addr, 0, allLedTurnOn);
}

void URX::LedControl::displayLed(int row, int col, int state) {
    if (row < 8 and col < 8) {
        setLed(1, 7 - col, row, state);
    }
    else if (row < 8 and col >= 8) {
        setLed(3, 7 - col % 8, row, state);
    }
    else if (row >= 8 and col < 8) {
        setLed(0, 7 - col, row % 8, state);
    }
    else if (row >= 8 and col >= 8) {
        setLed(2, 7 - col % 8, row % 8, state);
    }
}
void URX::LedControl::displayImage(const word* image, int displaySizeX = 8, int displaySizeY = 0, int display = 0, int offsetX = 0, int offsetY = 0) {
    int MirrorX = displaySizeX - 1;
    int MirrorY = displaySizeY - 1;
    for (int index = 0; index < 2; index++) {
        for (int rows = 0; rows < displaySizeX; rows++) {
            if (displaySizeX == 8 and displaySizeY == 0) {
                byte byte1 = (pgm_read_word(&image[(rows)+(index * displaySizeX)]) >> displaySizeX) & 0xFF;
                byte byte2 = pgm_read_word(&image[(rows)+(index * displaySizeX)]) & 0xFF;
                setRow(index + 1 + index, MirrorX - rows, byte1);
                setRow(index + index, MirrorX - rows, byte2);
            }
            else {
                for (int cols = 0; cols < displaySizeY; cols++) {
                    setLed(display, MirrorX - rows - offsetX, MirrorY - cols - offsetY, bitRead(pgm_read_word(&image[rows]), cols));
                }
            }
        }
    }
}
void URX::LedControl::displayNumbers(int number) {
    String gameScore = String(number);
    const word* nazev[] = { Zerox4,Onex4,Twox4,Threex4,Fourx4,Fivex4,Sixx4,Sevenx4,Eightx4,Ninex4 };
    for (int i = 0; i < gameScore.length(); i++) {
        if (i == 2) {
            displayImage(nazev[gameScore[i] - '0'], 4, 7, 2, -3, -1);
        }
        else {
            displayImage(nazev[gameScore[i] - '0'], 4, 7, 0, -4 + (i * 4), -1);
        }
    }
}
void U8G2::displayOled(String writing = "") {
    firstPage();
    do {
        int index = writing.lastIndexOf('\n');
        int length = writing.length();
        String first = writing.substring(0, index);
        setFont(u8g2_font_helvR12_tr);
        setCursor(0, 13);
        print(first);
        setCursor(0, 28);
        index = writing.lastIndexOf('\n');
        length = writing.length();
        String second = writing.substring(index, length);
        print(second);
    } while (nextPage());
}
#ifdef U8X8_USE_PINS
extern "C" uint8_t u8x8_gpio_and_delay_arduino(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, U8X8_UNUSED void *arg_ptr)
{
  uint8_t i;
  switch(msg)
  {
    case U8X8_MSG_GPIO_AND_DELAY_INIT:
    
      for( i = 0; i < U8X8_PIN_CNT; i++ )
	if ( u8x8->pins[i] != U8X8_PIN_NONE )
	{
	  if ( i < U8X8_PIN_OUTPUT_CNT )
	  {
	    pinMode(u8x8->pins[i], OUTPUT);
	  }
	  else
	  {
#ifdef INPUT_PULLUP
	    pinMode(u8x8->pins[i], INPUT_PULLUP);
#else
	    pinMode(u8x8->pins[i], OUTPUT);
	    digitalWrite(u8x8->pins[i], 1);
#endif 
	  }
	}
	  
      break;

#ifndef __AVR__	
    /* this case is not compiled for any AVR, because AVR uC are so slow */
    /* that this delay does not matter */
    case U8X8_MSG_DELAY_NANO:
      delayMicroseconds(arg_int==0?0:1);
      break;
#endif
    
    case U8X8_MSG_DELAY_10MICRO:
      /* not used at the moment */
      break;
    
    case U8X8_MSG_DELAY_100NANO:
      /* not used at the moment */
      break;
   
    case U8X8_MSG_DELAY_MILLI:
      delay(arg_int);
      break;
    case U8X8_MSG_DELAY_I2C:
      /* arg_int is 1 or 4: 100KHz (5us) or 400KHz (1.25us) */
      delayMicroseconds(arg_int<=2?5:2);
      break;
    case U8X8_MSG_GPIO_I2C_CLOCK:
    case U8X8_MSG_GPIO_I2C_DATA:
      if ( arg_int == 0 )
      {
	pinMode(u8x8_GetPinValue(u8x8, msg), OUTPUT);
	digitalWrite(u8x8_GetPinValue(u8x8, msg), 0);
      }
      else
      {
#ifdef INPUT_PULLUP
	pinMode(u8x8_GetPinValue(u8x8, msg), INPUT_PULLUP);
#else
	pinMode(u8x8_GetPinValue(u8x8, msg), OUTPUT);
	digitalWrite(u8x8_GetPinValue(u8x8, msg), 1);
#endif 
      }
      break;
    default:
      if ( msg >= U8X8_MSG_GPIO(0) )
      {
	i = u8x8_GetPinValue(u8x8, msg);
	if ( i != U8X8_PIN_NONE )
	{
	  if ( u8x8_GetPinIndex(u8x8, msg) < U8X8_PIN_OUTPUT_CNT )
	  {
	    digitalWrite(i, arg_int);
	  }
	  else
	  {
	    if ( u8x8_GetPinIndex(u8x8, msg) == U8X8_PIN_OUTPUT_CNT )
	    {
	      // call yield() for the first pin only, u8x8 will always request all the pins, so this should be ok
	      yield();
	    }
	    u8x8_SetGPIOResult(u8x8, digitalRead(i) == 0 ? 0 : 1);
	  }
	}
	break;
      }
      
      return 0;
  }
  return 1;
}
#endif // U8X8_USE_PINS

extern "C" uint8_t u8x8_byte_arduino_hw_i2c(U8X8_UNUSED u8x8_t *u8x8, U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int, U8X8_UNUSED void *arg_ptr)
{
#ifdef U8X8_HAVE_HW_I2C
  switch(msg)
  {
    case U8X8_MSG_BYTE_SEND:
      Wire.write((uint8_t *)arg_ptr, (int)arg_int);
      break;
    case U8X8_MSG_BYTE_INIT:
      if ( u8x8->bus_clock == 0 ) 	/* issue 769 */
	u8x8->bus_clock = u8x8->display_info->i2c_bus_clock_100kHz * 100000UL;
#if defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) || defined(ESP_PLATFORM) || defined(ARDUINO_ARCH_ESP32)
      /* for ESP8266/ESP32, Wire.begin has two more arguments: clock and data */          
      if ( u8x8->pins[U8X8_PIN_I2C_CLOCK] != U8X8_PIN_NONE && u8x8->pins[U8X8_PIN_I2C_DATA] != U8X8_PIN_NONE )
      {
	// second argument for the wire lib is the clock pin. In u8g2, the first argument of the  clock pin in the clock/data pair
	Wire.begin((int)u8x8->pins[U8X8_PIN_I2C_DATA] , u8x8->pins[U8X8_PIN_I2C_CLOCK]);
      }
      else
      {
	Wire.begin();
      }
#else
      Wire.begin();
#endif
      break;
    case U8X8_MSG_BYTE_SET_DC:
      break;
    case U8X8_MSG_BYTE_START_TRANSFER:
#if ARDUINO >= 10600
      /* not sure when the setClock function was introduced, but it is there since 1.6.0 */
      /* if there is any error with Wire.setClock() just remove this function call */
      Wire.setClock(u8x8->bus_clock); 
#endif
      Wire.beginTransmission(u8x8_GetI2CAddress(u8x8)>>1);
      break;
    case U8X8_MSG_BYTE_END_TRANSFER:
      Wire.endTransmission();
      break;
    default:
      return 0;
  }
#endif
  return 1;
}


