/*
 *    LedControl.h - A library for controling Leds with a MAX7219/MAX7221
 *    Copyright (c) 2007 Eberhard Fahle
*/
#ifndef Urx_h
#define Urx_h

#include <avr/pgmspace.h>
#include <Arduino.h>
#include <inttypes.h>
#include <avr/interrupt.h>
#include <pins_arduino.h>
#include <Print.h> 
#include <Wire.h>
#include <EEPROM.h>

#include "clib/u8g2.h"

#ifndef U8X8_NO_HW_I2C
#define U8X8_HAVE_HW_I2C
#endif

/* define U8X8_HAVE_2ND_HW_I2C if the board has a second wire interface*/
#ifdef U8X8_HAVE_HW_I2C
#ifdef WIRE_INTERFACES_COUNT
#if WIRE_INTERFACES_COUNT > 1
#define U8X8_HAVE_2ND_HW_I2C
#endif
#endif
#endif /* U8X8_HAVE_HW_I2C */

extern "C" uint8_t u8x8_gpio_and_delay_arduino(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
extern "C" uint8_t u8x8_byte_arduino_hw_i2c(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);
void u8x8_SetPin_HW_I2C(u8x8_t *u8x8, uint8_t reset, uint8_t clock = U8X8_PIN_NONE, uint8_t data = U8X8_PIN_NONE);

const PROGMEM static word Onex4[] = {
0B0000000, 
0B0100000, 
0B1111111, 
0B0000000, 
};
const PROGMEM static word Twox4[] = {
0B0100111, 
0B1001001, 
0B1001001, 
0B0110001, 
};
const PROGMEM static word Threex4[] = {
0B0100010, 
0B1001001, 
0B1001001, 
0B0110110, 
};
const PROGMEM static word Fourx4[] = {
0B1110000, 
0B0001000, 
0B0001000, 
0B1111111, 
};
const PROGMEM static word Fivex4[]= {
0B1110001, 
0B1001001, 
0B1001001, 
0B1000110, 
};
const PROGMEM static word Sixx4[] = {
0B0111110, 
0B1001001, 
0B1001001, 
0B1000110, 
};
const PROGMEM static word Sevenx4[] = {
0B1000000, 
0B1000000, 
0B1001111, 
0B1110000, 
};
const PROGMEM static word Eightx4[] = {
0B0110110, 
0B1001001, 
0B1001001, 
0B0110110, 
};
const PROGMEM static word Ninex4[] = {
0B0110001, 
0B1001001, 
0B1001001, 
0B0111110, 
};
const PROGMEM static word Zerox4[] = {
0B0111110, 
0B1000001, 
0B1000001, 
0B0111110, 
};
const PROGMEM static word GameOverMessage[]  = {
0B1111111111111111, 
0B1111110000111111, 
0B1111000111011111, 
0B1100001111101111, 
0B1100001111100001, 
0B1000001111100001, 
0B1000001111000011, 
0B1000000000011001, 
0B1000000000011001, 
0B1000001111000011, 
0B1000001111100001, 
0B1100001111100001, 
0B1100001111101111, 
0B1111000111011111, 
0B1111110000111111, 
0B1111111111111111, 
};
const PROGMEM static word Win[] = {
0B0000000000000000, 
0B0111000000000000, 
0B0100100000000000, 
0B0100010000000000, 
0B0111111100000010, 
0B0111111110000110, 
0B0111111111001110, 
0B0111111111111110, 
0B0111111111111110, 
0B0111111111001110, 
0B0111111110000110, 
0B0111111100000010, 
0B0100010000000000, 
0B0100100000000000, 
0B0111000000000000, 
0B0000000000000000, 
};
const PROGMEM static word Low[] = {
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0000000000000110, 
0B0000000000000110, 
0B0000000000000110, 
0B0000000000000110, 
0B0000000000000110, 
0B0000000000000110, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
};
const PROGMEM static word Easy[] = {
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0110000110000110, 
0B0110000110000110, 
0B0110000110000110, 
0B0110000110000110, 
0B0110000110000110, 
0B0110000110000110, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
};
const PROGMEM static word Medium[] = {
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0011110000000000, 
0B0000111100000000, 
0B0000111100000000, 
0B0011110000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
};
const PROGMEM static word High[]  = {
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
0B0000000000000000, 
};
const PROGMEM static word ArrowUp[] = {
0B0000000000000000, 
0B0000000100000000, 
0B0000001100000000, 
0B0000011100000000, 
0B0000111000000000, 
0B0001110000000000, 
0B0011100000000000, 
0B0111111111111110, 
0B0111111111111110, 
0B0011100000000000, 
0B0001110000000000, 
0B0000111000000000, 
0B0000011100000000, 
0B0000001100000000, 
0B0000000100000000, 
0B0000000000000000, 
};
const PROGMEM static word ArrowDown[]  = {
0B0000000000000000, 
0B0000000010000000, 
0B0000000011000000, 
0B0000000011100000, 
0B0000000001110000, 
0B0000000000111000, 
0B0000000000011100, 
0B0111111111111110, 
0B0111111111111110, 
0B0000000000011100, 
0B0000000000111000, 
0B0000000001110000, 
0B0000000011100000, 
0B0000000011000000, 
0B0000000010000000, 
0B0000000000000000, 
};
const PROGMEM static word ArrowRight[] = {
0B0000000000000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0111000110001110, 
0B0011100110011100, 
0B0001110110111000, 
0B0000111111110000, 
0B0000011111100000, 
0B0000001111000000, 
0B0000000110000000, 
0B0000000000000000, 
};
const PROGMEM static word ArrowLeft[] = {
0B0000000000000000, 
0B0000000110000000, 
0B0000001111000000, 
0B0000011111100000, 
0B0000111111110000, 
0B0001110110111000, 
0B0011100110011100, 
0B0111000110001110, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000110000000, 
0B0000000000000000, 
};
const PROGMEM static word PushA[] = {
0B0000000000000000, 
0B0111110000000000, 
0B0101000000000000, 
0B0010000000000000, 
0B0000000000000000, 
0B0111100000001110, 
0B0000010001110000, 
0B0111100010010000, 
0B0000000010010000, 
0B0111010001110000, 
0B0101110000001110, 
0B0000000000000000, 
0B0111110000000000, 
0B0001000000000000, 
0B0111110000000000, 
0B0000000000000000, 
};
const PROGMEM static word NewSong[] = {
0B0000000000000000, 
0B0111110000000000, 
0B0011000000000000, 
0B0001100000000000, 
0B0111110000000000, 
0B0000000000011000, 
0B0111110000111100, 
0B0101010000111100, 
0B0101010001111110, 
0B0000000000000000, 
0B0111000000111100, 
0B0000110000000000, 
0B0001100000000000, 
0B0000110000000000, 
0B0111000000000000, 
0B0000000000000000, 
};
const PROGMEM static word Score[] = {
0B0111010000000000, 
0B0101110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0100010000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0100010000000000, 
0B0111110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0101000000000000, 
0B0010110000000000, 
0B0000000000000000, 
0B0111110000000000, 
0B0101010000000000, 
};
const PROGMEM static word SnakeMenu[]= {
0B1101, 
0B1101, 
0B1011, 
0B1011, 
};
const PROGMEM static word Nastaveni1[] = {
0B0010, 
0B1110, 
0B0111, 
0B0100, 
};

const PROGMEM static word Nastaveni2[] = {
0B0100, 
0B0111, 
0B1110, 
0B0010, 
};
const PROGMEM static word Intensity[] = {
0B1001, 
0B1111, 
0B1111, 
0B1001, 
};
const PROGMEM static word DancemanMenu[] = {
0B1111, 
0B1001, 
0B1001, 
0B0110, 
};
const PROGMEM static word HighScore[] = {
0B1111, 
0B0100, 
0B0100, 
0B1111, 
};
const PROGMEM static word Galaxian[] = {
0B0110, 
0B1011, 
0B1011, 
0B1010, 
};
const PROGMEM static word HolTyc1[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000000010, 
0B0100000000000010, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000000010, 
0B0100000000000010, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc2[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000001110, 
0B0100000000001110, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000001110, 
0B0100000000001110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc3[] = {
0B0000000110000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000111110, 
0B0100000000111110, 
0B0011111001111100, 
0B0000001001000000, 
0B0000001001000000, 
0B0011111001111100, 
0B0100000000111110, 
0B0100000000111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc4[] = {
0B0000000110000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0000001011000000, 
0B0011111011111100, 
0B0100000011111110, 
0B0100000011111110, 
0B0011111011111100, 
0B0000001011000000, 
0B0000001011000000, 
0B0011111011111100, 
0B0100000011111110, 
0B0100000011111110, 
0B0011111111111100, 
0B0000000000000000, 
};

const PROGMEM static word HolTyc5[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100001111111110, 
0B0100001111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100001111111110, 
0B0100001111111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc6[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100111111111110, 
0B0100111111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0100111111111110, 
0B0100111111111110, 
0B0011111111111100, 
0B0000000000000000, 
};
const PROGMEM static word HolTyc7[] = {
0B0000000110000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0111111111111110, 
0B0111111111111110, 
0B0011111111111100, 
0B0000001111000000, 
0B0000001111000000, 
0B0011111111111100, 
0B0111111111111110, 
0B0111111111111110, 
0B0011111111111100, 
0B0000000000000000, 
};

const PROGMEM static word Gold_medal[] = { 
0B0101, 
0B1001, 
0B1111, 
0B0001, 
};
const PROGMEM static word Silver_medal[] = { 
0B0101, 
0B1001, 
0B1011, 
0B0101,
};
const PROGMEM static word Sound_on[] = {
0B001100, 
0B011110, 
0B011110, 
0B111111, 
0B000000, 
0B011110, 
};
const PROGMEM static word Sound_off[] = {
0B001100, 
0B011110, 
0B011110, 
0B111111, 
0B000000, 
0B000000, 
};
const PROGMEM static byte ship[3][2] = {
	{1,0},
	{1,1},
	{1,0}};
extern int Array[16][16];
extern int EnemysG[101];
extern int EnemyDouble[51];
extern int bulletPosition[2];
extern int enBulletPosition1[4];
extern int enBulletPosition2[4];
extern int Enemys[6];
class LedControl {
	private:
        /* The array for shifting the data to the devices */
        byte spidata[16];
        /* Send out a single command to the device */
        void spiTransfer(int addr, byte opcode, byte data);

        /* We keep track of the led-status for all 8 devices in this array */
        byte status[64];
        /* Data is shifted out of this pin*/
        int SPI_MOSI;
        /* The clock is signaled on this pin */
        int SPI_CLK;
        /* This one is driven LOW for chip selectzion */
        int SPI_CS;
        /* The maximum number of devices we use */
        int maxDevices;

    public:
        /* 
         * Create a new controler 
         * Params :
         * dataPin		pin on the Arduino where data gets shifted out
         * clockPin		pin for the clock
         * csPin		pin for selecting the device 
         * numDevices	maximum number of devices that can be controled
         */
        LedControl(int dataPin, int clkPin, int csPin, int numDevices=1);

        /* 
         * Set the shutdown (power saving) mode for the device
         * Params :
         * addr	The address of the display to control
         * status	If true the device goes into power-down mode. Set to false
         *		for normal operation.
         */
        void shutdown(int addr, bool status);

        /* 
         * Set the number of digits (or rows) to be displayed.
         * See datasheet for sideeffects of the scanlimit on the brightness
         * of the display.
         * Params :
         * addr	address of the display to control
         * limit	number of digits to be displayed (1..8)
         */
        void setScanLimit(int addr, int limit);

        /* 
         * Set the brightness of the display.
         * Params:
         * addr		the address of the display to control
         * intensity	the brightness of the display. (0..15)
         */
        void setIntensity(int addr, int intensity);

        /* 
         * Switch all Leds on the display off. 
         * Params:
         * addr	address of the display to control
         */
        void clearDisplay(int addr);

        /* 
         * Set the status of a single Led.
         * Params :
         * addr	address of the display 
         * row	the row of the Led (0..7)
         * col	the column of the Led (0..7)
         * state	If true the led is switched on, 
         *		if false it is switched off
         */
        void setLed(int addr, int row, int col, boolean state);

        /* 
         * Set all 8 Led's in a row to a new state
         * Params:
         * addr	address of the display
         * row	row which is to be set (0..7)
         * value	each bit set to 1 will light up the
         *		corresponding Led.
         */
        void setRow(int addr, int row, byte value);

        /* 
         * Set all 8 Led's in a column to a new state
         * Params:
         * addr	address of the display
         * col	column which is to be set (0..7)
         * value	each bit set to 1 will light up the
         *		corresponding Led.
         */
        void setColumn(int addr, int col, byte value);

};


class U8X8
#ifdef ARDUINO
: public Print
#endif
{
  protected:
    u8x8_t u8x8;
  public:
    uint8_t tx, ty;
  
    U8X8(void) { home();  }
    u8x8_t *getU8x8(void) { return &u8x8; }

    void home(void) { tx = 0; ty = 0; }
};

class U8G2
#ifdef ARDUINO
: public Print
#endif
{
  protected:
    u8g2_t u8g2;
    u8x8_char_cb cpp_next_cb; /*  the cpp interface has its own decoding function for the Arduino print command */
  public:
    u8g2_uint_t tx, ty;
  
    U8G2(void) { cpp_next_cb = u8x8_ascii_next; home(); }
    
    u8g2_t *getU8g2(void) { return &u8g2; }
 
    void initDisplay(void) {
      u8g2_InitDisplay(&u8g2); }
      
    void clearDisplay(void) {
      u8g2_ClearDisplay(&u8g2); }
      
    void setPowerSave(uint8_t is_enable) {
      u8g2_SetPowerSave(&u8g2, is_enable); }
      
    void setFlipMode(uint8_t mode) {
      u8g2_SetFlipMode(&u8g2, mode); }

      
    

    
    bool begin(void) {
      /* note: call to u8x8_utf8_init is not required here, this is done in the setup procedures before */
      #ifndef U8G2_USE_DYNAMIC_ALLOC
      initDisplay(); 
      clearDisplay(); 
      setPowerSave(0); 
      return 1;
      #else
      return 0;
      #endif
    }

      



    void firstPage(void) { u8g2_FirstPage(&u8g2); }
    uint8_t nextPage(void) { return u8g2_NextPage(&u8g2); }


    void setFont(const uint8_t  *font) {u8g2_SetFont(&u8g2, font); } 

    
    u8g2_uint_t drawGlyph(u8g2_uint_t x, u8g2_uint_t y, uint16_t encoding) { return u8g2_DrawGlyph(&u8g2, x, y, encoding); }    

    size_t write(uint8_t v) {
      uint16_t e = cpp_next_cb(&(u8g2.u8x8), v);
      
      if ( e < 0x0fffe )
      {
	u8g2_uint_t delta = u8g2_DrawGlyph(&u8g2, tx, ty, e);
	
#ifdef U8G2_WITH_FONT_ROTATION
	switch(u8g2.font_decode.dir)
	{
	  case 0:
	    tx += delta;
	    break;
	  case 1:
	    ty += delta;
	    break;
	  case 2:
	    tx -= delta;
	    break;
	  case 3:
	    ty -= delta;
	    break;
	}
	
	// requires 10 bytes more on avr
	//tx = u8g2_add_vector_x(tx, delta, 0, u8g2.font_decode.dir);
	//ty = u8g2_add_vector_y(ty, delta, 0, u8g2.font_decode.dir);

#else
	tx += delta;
#endif
      }
      return 1;
     }

    size_t write(const uint8_t *buffer, size_t size) {
      size_t cnt = 0;
      while( size > 0 ) {
	cnt += write(*buffer++); 
	size--;
      }
      return cnt;
    }

     /* LiquidCrystal compatible functions */
    void home(void) { tx = 0; ty = 0;  u8x8_utf8_init(u8g2_GetU8x8(&u8g2)); }
    void setCursor(u8g2_uint_t x, u8g2_uint_t y) { tx = x; ty = y; }
};


class U8G2LOG
#ifdef ARDUINO
: public Print
#endif
{
  
  public:
    u8log_t u8log;

    /* virtual function for print base class */    
    size_t write(uint8_t v) {
      u8log_WriteChar(&u8log, v);
      return 1;
     }

    size_t write(const uint8_t *buffer, size_t size) {
      size_t cnt = 0;
      while( size > 0 ) {
	cnt += write(*buffer++); 
	size--;
      }
      return cnt;
    }    
};


class U8G2_SH1106_128X32_VISIONOX_F_HW_I2C : public U8G2 {
public: U8G2_SH1106_128X32_VISIONOX_F_HW_I2C(const u8g2_cb_t* rotation, uint8_t reset = U8X8_PIN_NONE, uint8_t clock = U8X8_PIN_NONE, uint8_t data = U8X8_PIN_NONE) : U8G2() {
    u8g2_Setup_sh1106_i2c_128x32_visionox_1(&u8g2, rotation, u8x8_byte_arduino_hw_i2c, u8x8_gpio_and_delay_arduino);
}
};


#endif
